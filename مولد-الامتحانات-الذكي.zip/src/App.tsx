import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { UploadCloud, FileText, Clock, CheckCircle, XCircle, AlertCircle, RefreshCw, Play, ChevronRight, ChevronLeft, Award, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Types
interface Question {
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

interface Exam {
  title: string;
  timeLimitMinutes: number;
  questions: Question[];
}

type AppState = 'IDLE' | 'GENERATING' | 'EXAM_READY' | 'TAKING_EXAM' | 'RESULTS';
type Language = 'ar' | 'en';

const translations = {
  ar: {
    title: 'مولد الامتحانات الذكي',
    heroTitle: 'حول ملفات PDF إلى امتحانات تفاعلية',
    heroSubtitle: 'ارفع أي ملف PDF وسيقوم الذكاء الاصطناعي بتحليله واستخراج أسئلة اختيار من متعدد مع إجاباتها وتحديد وقت للامتحان.',
    uploadText: 'اضغط لرفع ملف PDF',
    uploadSubtext: 'الحد الأقصى يعتمد على حجم الملف',
    errorInvalidFile: 'الرجاء رفع ملف PDF صالح.',
    errorGeneration: 'حدث خطأ أثناء إنشاء الامتحان. قد يكون الملف كبيراً جداً أو غير مقروء.',
    generatingTitle: 'جاري تحليل الملف...',
    generatingSubtitle: 'يقوم الذكاء الاصطناعي بقراءة المحتوى واستخراج الأسئلة',
    examReady: 'تم إنشاء الامتحان بنجاح!',
    questionsCount: 'أسئلة',
    minutes: 'دقيقة',
    startExam: 'ابدأ الامتحان الآن',
    cancel: 'إلغاء',
    question: 'السؤال',
    of: 'من',
    next: 'التالي',
    previous: 'السابق',
    finishExam: 'إنهاء الامتحان',
    finalScore: 'النتيجة النهائية',
    timeTaken: 'الوقت المستغرق:',
    percentage: 'النسبة المئوية:',
    reviewAnswers: 'مراجعة الإجابات',
    explanation: 'الشرح:',
    newExam: 'إنشاء امتحان جديد',
    aiPrompt: `قم بتحليل ملف الـ PDF المرفق وقم بإنشاء امتحان اختيار من متعدد بناءً على محتواه.
يجب أن يكون الامتحان باللغة العربية.
قم بإنشاء 5 إلى 10 أسئلة تغطي أهم النقاط في الملف.
قم بإرجاع الرد بتنسيق JSON بالهيكل التالي:
{
  "title": "عنوان الامتحان",
  "timeLimitMinutes": 10,
  "questions": [
    {
      "question": "نص السؤال؟",
      "options": ["خيار 1", "خيار 2", "خيار 3", "خيار 4"],
      "correctAnswerIndex": 0,
      "explanation": "شرح الإجابة الصحيحة."
    }
  ]
}`
  },
  en: {
    title: 'Smart Exam Generator',
    heroTitle: 'Turn PDFs into Interactive Exams',
    heroSubtitle: 'Upload any PDF file and AI will analyze it to extract multiple-choice questions, answers, and set a time limit.',
    uploadText: 'Click to upload PDF',
    uploadSubtext: 'Max size depends on the file',
    errorInvalidFile: 'Please upload a valid PDF file.',
    errorGeneration: 'An error occurred while generating the exam. The file might be too large or unreadable.',
    generatingTitle: 'Analyzing file...',
    generatingSubtitle: 'AI is reading the content and extracting questions',
    examReady: 'Exam generated successfully!',
    questionsCount: 'Questions',
    minutes: 'Minutes',
    startExam: 'Start Exam Now',
    cancel: 'Cancel',
    question: 'Question',
    of: 'of',
    next: 'Next',
    previous: 'Previous',
    finishExam: 'Finish Exam',
    finalScore: 'Final Score',
    timeTaken: 'Time Taken:',
    percentage: 'Percentage:',
    reviewAnswers: 'Review Answers',
    explanation: 'Explanation:',
    newExam: 'Create New Exam',
    aiPrompt: `Analyze the attached PDF file and create a multiple-choice exam based on its content.
The exam must be in English.
Create 5 to 10 questions covering the most important points in the file.
Return the response in JSON format with the following structure:
{
  "title": "Exam Title",
  "timeLimitMinutes": 10,
  "questions": [
    {
      "question": "Question text?",
      "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
      "correctAnswerIndex": 0,
      "explanation": "Explanation of the correct answer."
    }
  ]
}`
  }
};

export default function App() {
  const [appState, setAppState] = useState<AppState>('IDLE');
  const [exam, setExam] = useState<Exam | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lang, setLang] = useState<Language>('ar');
  const t = translations[lang];
  
  // Exam State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [timeTaken, setTimeTaken] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Update document direction based on language
  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  // Timer Effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (appState === 'TAKING_EXAM' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
        setTimeTaken(prev => prev + 1);
      }, 1000);
    } else if (appState === 'TAKING_EXAM' && timeLeft === 0) {
      handleSubmitExam();
    }
    return () => clearInterval(timer);
  }, [appState, timeLeft]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.type !== 'application/pdf') {
      setError(t.errorInvalidFile);
      return;
    }
    
    setAppState('GENERATING');
    setError(null);
    
    try {
      const base64 = await fileToBase64(file);
      const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY });
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          {
            parts: [
              {
                inlineData: {
                  mimeType: 'application/pdf',
                  data: base64.split(',')[1]
                }
              },
              {
                text: t.aiPrompt
              }
            ]
          }
        ],
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              timeLimitMinutes: { type: Type.INTEGER },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    options: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING }
                    },
                    correctAnswerIndex: { type: Type.INTEGER },
                    explanation: { type: Type.STRING }
                  },
                  required: ['question', 'options', 'correctAnswerIndex', 'explanation']
                }
              }
            },
            required: ['title', 'timeLimitMinutes', 'questions']
          }
        }
      });

      const generatedExam = JSON.parse(response.text) as Exam;
      setExam(generatedExam);
      setTimeLeft(generatedExam.timeLimitMinutes * 60);
      setAppState('EXAM_READY');
    } catch (err) {
      console.error(err);
      setError(t.errorGeneration);
      setAppState('IDLE');
    }
  };

  const startExam = () => {
    setAppState('TAKING_EXAM');
    setCurrentQuestionIndex(0);
    setUserAnswers({});
    setTimeTaken(0);
  };

  const handleAnswerSelect = (optionIndex: number) => {
    setUserAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: optionIndex
    }));
  };

  const handleSubmitExam = () => {
    setAppState('RESULTS');
  };

  const resetApp = () => {
    setAppState('IDLE');
    setExam(null);
    setError(null);
    setUserAnswers({});
    setTimeLeft(0);
    setTimeTaken(0);
    setCurrentQuestionIndex(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const calculateScore = () => {
    if (!exam) return 0;
    let score = 0;
    exam.questions.forEach((q, i) => {
      if (userAnswers[i] === q.correctAnswerIndex) score++;
    });
    return score;
  };

  const toggleLanguage = () => {
    setLang(prev => prev === 'ar' ? 'en' : 'ar');
  };

  return (
    <div className={`min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900 ${lang === 'ar' ? 'dir-rtl' : 'dir-ltr'}`}>
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-indigo-600 font-bold text-xl">
            <Award className="w-6 h-6" />
            <span>{t.title}</span>
          </div>
          
          <div className="flex items-center gap-4">
            {appState === 'TAKING_EXAM' && (
              <div className={`flex items-center gap-2 font-mono font-medium px-4 py-1.5 rounded-full ${timeLeft < 60 ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'}`}>
                <Clock className="w-4 h-4" />
                {formatTime(timeLeft)}
              </div>
            )}
            
            {appState === 'IDLE' && (
              <button 
                onClick={toggleLanguage}
                className="flex items-center gap-2 text-slate-600 hover:text-indigo-600 transition-colors font-medium px-3 py-1.5 rounded-lg hover:bg-slate-100"
              >
                <Globe className="w-4 h-4" />
                {lang === 'ar' ? 'English' : 'العربية'}
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-12">
        <AnimatePresence mode="wait">
          
          {/* IDLE STATE */}
          {appState === 'IDLE' && (
            <motion.div
              key="idle"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center justify-center text-center space-y-8"
            >
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight">
                  {lang === 'ar' ? (
                    <>حول ملفات <span className="text-indigo-600">PDF</span> إلى امتحانات تفاعلية</>
                  ) : (
                    <>Turn <span className="text-indigo-600">PDFs</span> into Interactive Exams</>
                  )}
                </h1>
                <p className="text-lg text-slate-600 max-w-xl mx-auto">
                  {t.heroSubtitle}
                </p>
              </div>

              <div 
                className="w-full max-w-md p-8 border-2 border-dashed border-slate-300 rounded-3xl bg-white hover:border-indigo-400 hover:bg-indigo-50/50 transition-colors cursor-pointer group relative"
                onClick={() => fileInputRef.current?.click()}
              >
                <input 
                  type="file" 
                  accept="application/pdf" 
                  className="hidden" 
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                />
                <div className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <UploadCloud className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-lg font-medium text-slate-900">{t.uploadText}</p>
                    <p className="text-sm text-slate-500 mt-1">{t.uploadSubtext}</p>
                  </div>
                </div>
              </div>

              {error && (
                <div className={`flex items-center gap-2 text-red-600 bg-red-50 px-4 py-3 rounded-xl w-full max-w-md ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <p className="text-sm">{error}</p>
                </div>
              )}
            </motion.div>
          )}

          {/* GENERATING STATE */}
          {appState === 'GENERATING' && (
            <motion.div
              key="generating"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex flex-col items-center justify-center py-20 space-y-6"
            >
              <div className="relative">
                <div className="w-20 h-20 border-4 border-indigo-100 rounded-full"></div>
                <div className="w-20 h-20 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin absolute top-0 left-0"></div>
                <FileText className="w-8 h-8 text-indigo-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
              </div>
              <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold text-slate-900">{t.generatingTitle}</h2>
                <p className="text-slate-500">{t.generatingSubtitle}</p>
              </div>
            </motion.div>
          )}

          {/* EXAM READY STATE */}
          {appState === 'EXAM_READY' && exam && (
            <motion.div
              key="ready"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200 text-center space-y-8"
            >
              <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-10 h-10" />
              </div>
              
              <div className="space-y-2">
                <h2 className="text-3xl font-bold text-slate-900">{exam.title}</h2>
                <p className="text-slate-500">{t.examReady}</p>
              </div>

              <div className="flex flex-wrap justify-center gap-4">
                <div className="flex items-center gap-2 bg-slate-50 px-4 py-3 rounded-2xl border border-slate-100">
                  <FileText className="w-5 h-5 text-indigo-600" />
                  <span className="font-medium">{exam.questions.length} {t.questionsCount}</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-50 px-4 py-3 rounded-2xl border border-slate-100">
                  <Clock className="w-5 h-5 text-indigo-600" />
                  <span className="font-medium">{exam.timeLimitMinutes} {t.minutes}</span>
                </div>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  onClick={startExam}
                  className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-colors"
                >
                  <Play className="w-5 h-5" />
                  {t.startExam}
                </button>
                <button
                  onClick={resetApp}
                  className="flex items-center justify-center gap-2 bg-slate-100 text-slate-700 px-6 py-4 rounded-xl font-medium hover:bg-slate-200 transition-colors"
                >
                  {t.cancel}
                </button>
              </div>
            </motion.div>
          )}

          {/* TAKING EXAM STATE */}
          {appState === 'TAKING_EXAM' && exam && (
            <motion.div
              key="taking"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              {/* Progress Bar */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm font-medium text-slate-500">
                  <span>{t.question} {currentQuestionIndex + 1} {t.of} {exam.questions.length}</span>
                  <span>{Math.round(((currentQuestionIndex + 1) / exam.questions.length) * 100)}%</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full bg-indigo-600 transition-all duration-300 ease-out`}
                    style={{ width: `${((currentQuestionIndex + 1) / exam.questions.length) * 100}%` }}
                  />
                </div>
              </div>

              {/* Question Card */}
              <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-slate-200">
                <h3 className="text-xl md:text-2xl font-bold text-slate-900 mb-8 leading-relaxed">
                  {exam.questions[currentQuestionIndex].question}
                </h3>

                <div className="space-y-3">
                  {exam.questions[currentQuestionIndex].options.map((option, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleAnswerSelect(idx)}
                      className={`w-full p-4 rounded-2xl border-2 ${lang === 'ar' ? 'text-right' : 'text-left'} transition-all flex items-center gap-4 ${
                        userAnswers[currentQuestionIndex] === idx
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                          : 'border-slate-100 hover:border-indigo-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        userAnswers[currentQuestionIndex] === idx
                          ? 'border-indigo-600'
                          : 'border-slate-300'
                      }`}>
                        {userAnswers[currentQuestionIndex] === idx && <div className="w-3 h-3 bg-indigo-600 rounded-full" />}
                      </div>
                      <span className="text-lg">{option}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between pt-4">
                <button
                  onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
                  disabled={currentQuestionIndex === 0}
                  className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:hover:bg-transparent transition-colors ${lang === 'ar' ? 'flex-row-reverse' : ''}`}
                >
                  {lang === 'ar' ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
                  {t.previous}
                </button>

                {currentQuestionIndex === exam.questions.length - 1 ? (
                  <button
                    onClick={handleSubmitExam}
                    className={`flex items-center gap-2 bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors ${lang === 'ar' ? 'flex-row-reverse' : ''}`}
                  >
                    {t.finishExam}
                    <CheckCircle className="w-5 h-5" />
                  </button>
                ) : (
                  <button
                    onClick={() => setCurrentQuestionIndex(prev => Math.min(exam.questions.length - 1, prev + 1))}
                    className={`flex items-center gap-2 bg-indigo-100 text-indigo-700 px-6 py-3 rounded-xl font-bold hover:bg-indigo-200 transition-colors ${lang === 'ar' ? 'flex-row-reverse' : ''}`}
                  >
                    {t.next}
                    {lang === 'ar' ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
                  </button>
                )}
              </div>
            </motion.div>
          )}

          {/* RESULTS STATE */}
          {appState === 'RESULTS' && exam && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              {/* Score Summary */}
              <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200 text-center">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-indigo-50 text-indigo-600 mb-6">
                  <Award className="w-12 h-12" />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 mb-2">{t.finalScore}</h2>
                <div className="text-5xl font-black text-indigo-600 mb-6">
                  {calculateScore()} <span className="text-2xl text-slate-400 font-medium">/ {exam.questions.length}</span>
                </div>
                
                <div className="flex flex-wrap justify-center gap-4 text-sm">
                  <div className="bg-slate-50 px-4 py-2 rounded-lg border border-slate-100">
                    <span className="text-slate-500">{t.timeTaken}</span>{' '}
                    <span className="font-bold text-slate-900">{formatTime(timeTaken)}</span>
                  </div>
                  <div className="bg-slate-50 px-4 py-2 rounded-lg border border-slate-100">
                    <span className="text-slate-500">{t.percentage}</span>{' '}
                    <span className="font-bold text-slate-900">{Math.round((calculateScore() / exam.questions.length) * 100)}%</span>
                  </div>
                </div>
              </div>

              {/* Detailed Review */}
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-slate-900 px-2">{t.reviewAnswers}</h3>
                {exam.questions.map((q, idx) => {
                  const userAnswer = userAnswers[idx];
                  const isCorrect = userAnswer === q.correctAnswerIndex;
                  const isUnanswered = userAnswer === undefined;

                  return (
                    <div key={idx} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
                      <div className="flex gap-3 items-start">
                        <div className={`shrink-0 mt-1 ${isCorrect ? 'text-emerald-500' : 'text-red-500'}`}>
                          {isCorrect ? <CheckCircle className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                        </div>
                        <div>
                          <h4 className="text-lg font-bold text-slate-900">{q.question}</h4>
                        </div>
                      </div>

                      <div className={`space-y-2 ${lang === 'ar' ? 'pr-9' : 'pl-9'}`}>
                        {q.options.map((opt, optIdx) => {
                          let optClass = `p-3 rounded-xl border ${lang === 'ar' ? 'text-right' : 'text-left'} `;
                          if (optIdx === q.correctAnswerIndex) {
                            optClass += "bg-emerald-50 border-emerald-200 text-emerald-900 font-medium";
                          } else if (optIdx === userAnswer && !isCorrect) {
                            optClass += "bg-red-50 border-red-200 text-red-900";
                          } else {
                            optClass += "bg-slate-50 border-slate-100 text-slate-500";
                          }

                          return (
                            <div key={optIdx} className={optClass}>
                              {opt}
                            </div>
                          );
                        })}
                      </div>

                      <div className={`${lang === 'ar' ? 'pr-9' : 'pl-9'} pt-2`}>
                        <div className="bg-indigo-50 text-indigo-900 p-4 rounded-xl text-sm leading-relaxed">
                          <span className="font-bold block mb-1">{t.explanation}</span>
                          {q.explanation}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex justify-center pt-8 pb-12">
                <button
                  onClick={resetApp}
                  className={`flex items-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-slate-800 transition-colors ${lang === 'ar' ? 'flex-row-reverse' : ''}`}
                >
                  <RefreshCw className="w-5 h-5" />
                  {t.newExam}
                </button>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>
    </div>
  );
}
